//
//  KPContactManager.h
//  FriendVeritySDK
//
//  Created by QiJia on 2020/2/27.
//  Copyright © 2020 xjq. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN

typedef void(^FriendVerityBlock)(BOOL success);

@interface KPFriendVerityManager : NSObject

@property (nonatomic ,copy) NSString *currentUserId;

+ (instancetype)shareInstance;

//验证结果回调block

@property (nonatomic ,strong) FriendVerityBlock resultBlock;

/// SDK初始化
/// @param userId 当前登录用户的用户id
- (void)initWithUserId:(NSString*)userId;


/// 注册新用户
/// @param userId 用户id
/// @param avaterUrl 用户头像URL,远程访问地址
/// @param phone 用户电话号码
/// @param nickName 用户昵称
/// @param gender 用户性别 1：男 2：女  0：未知
/// @param success 成功回调
/// @param failure 失败回调

- (void)registerUserWithUserId:(NSString*)userId
                     avaterUrl:(NSString*)avaterUrl
                         phone:(NSString*)phone
                      nickName:(NSString *)nickName
                        gender:(NSString*)gender
                       success:(void (^)(id response))success
                       failure:(void (^)(NSError *error))failure;


/// 上传通讯录

- (void)uploadContactSuccess:(void (^)(id response))success failure:(void (^)(NSError *error))failure;


/// 获取全部好友

- (void)getFriendsArraySuccess:(void (^)(id response))success failure:(void (^)(NSError *error))failure;


/// 添加参与验证的好友
/// @param friendUserIdArray 参与验证的好友用户id
/// @param success 成功回调
/// @param failure 失败回调

-(void)addFriendsToParticipateInValidationWithFriendUserIdArray:(NSArray*)friendUserIdArray success:(void (^)(id response))success failure:(void (^)(NSError *error))failure;


/// 查询参与验证的好友

- (void)queryFriendsToParticipateInValidationSuccess:(void (^)(id response))success failure:(void (^)(NSError *error))failure;


/// 删除参与验证的好友
/// @param friendUserIdArray 被删除参与验证的好友用户id
/// @param success 成功回调
/// @param failure 失败回调

-(void)deleteFriendsToParticipateInValidationWithFriendUserIdArray:(NSArray*)friendUserIdArray success:(void (^)(id response))success failure:(void (^)(NSError *error))failure;

/// 查看动态列表

- (void)queryDynamicSuccess:(void (^)(id response))success failure:(void (^)(NSError *error))failure;


/// 帮助好友进行验证

- (void)startFriendVerityWithTaskId:(NSString*)taskId;


/// 本人进行好友验证

- (void)startFriendVerity;


/// 上传头像
/// @param image 头像image对象
/// @param success 成功回调
/// @param failure 失败回调

- (void)uploadAvaterWithImage:(UIImage*)image success:(void (^)(NSString *url))success failure:(void (^)(NSString *msg))failure;


/// 修改用户信息
/// @param avaterUrl 用户头像URL，远程访问地址
/// @param phone 用户手机号码
/// @param nickName 用户昵称
/// @param success 成功回调
/// @param failure 失败回调

- (void)aleterUserInfoWithAvaterUrl:(NSString*)avaterUrl
                              phone:(NSString*)phone
                           nickName:(NSString *)nickName
                            success:(void (^)(id response))success
                            failure:(void (^)(NSError *error))failure;

//初始化密切接触者管理管理对象

- (void)createCloseContactsManager;
@end

NS_ASSUME_NONNULL_END
